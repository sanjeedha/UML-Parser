package com.sanjeedha.umlparser;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.io.*;
import com.github.javaparser.ast.*;
import com.github.javaparser.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.body.*;
import java.util.HashMap;

import java.nio.charset.StandardCharsets;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.type.Type;
import net.sourceforge.plantuml.SourceStringReader;

import com.github.javaparser.ast.body.ModifierSet;
import com.github.javaparser.ast.AccessSpecifier;

import com.sun.deploy.util.StringUtils;


public class UMLParserSeq {

    public static void main(String[] args) throws Exception {

        UMLParserSeq parser = new UMLParserSeq();

        if (args.length == 1) {
            String outputImage = "output.png";

            File folderName = new File(args[0]);

            if (folderName.isDirectory()) {
                parser.parse(folderName, outputImage);
            } else {
                throw new FileNotFoundException("Please enter a valid folder path");
            }
        } else if (args.length == 2) {
            File folderName = new File(args[0]);
            String outputImage = args[1];

            if (folderName.isDirectory()) {
                parser.parse(folderName, outputImage);
            } else {
                throw new FileNotFoundException("Please enter a valid folder path");
            }
        }

    }

    private void parse(File folderName, String outputImage) throws Exception {
        ArrayList<String> javaFiles = getJavaFiles(folderName);

        StringBuilder inputStringBuilder = new StringBuilder();
        for (String file : javaFiles) {
            FileInputStream fis = new FileInputStream(file);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
            String line = bufferedReader.readLine();
            while(line != null){
                inputStringBuilder.append(line);inputStringBuilder.append('\n');
                line = bufferedReader.readLine();
            }
        }

        String ipStreamStr = inputStringBuilder.toString();

        ipStreamStr = ipStreamStr.replace("import", "// import");
        ipStreamStr = ipStreamStr.replace("package", "// package");

        InputStream in = new ByteArrayInputStream(ipStreamStr.getBytes(StandardCharsets.UTF_8));

        CompilationUnit cu;
        try {
            // parse the file
            cu = JavaParser.parse(in);
        } finally {
            in.close();
        }

        //ArrayList bigArray = new ArrayList();
        ArrayList classNames = getClasses(cu);
        ArrayList<HashMap<String, ArrayList>> methodMaps = new ArrayList<HashMap<String, ArrayList>>();
        for (TypeDeclaration typeDec : cu.getTypes()) {
            String className = typeDec.getName();
            if(classNames.contains(className))
            {
                List<BodyDeclaration> members = typeDec.getMembers();
                if (members != null && members.size() > 0) {
                    for (BodyDeclaration member : members) {
                        if (member instanceof MethodDeclaration) {
                            HashMap<String, ArrayList> methodMap = getMethodInfo(member);
                            if (!methodMap.isEmpty()) {
                                methodMaps.add(methodMap);
                            }
                        }
                    }


                }
            }
        }

        ArrayList<String> grammars = new ArrayList<String>();

        String grammar = "@startuml\n";
        boolean flag = true;

        for (HashMap<String, ArrayList> mm: methodMaps) {
            for (Map.Entry<String, ArrayList> hm: mm.entrySet()) {
                String sendClass = hm.getKey().split("-")[0];
                String sendMethod = hm.getKey().split("-")[1];

                int i = 0;
                for (Object toInfo: hm.getValue()) {
                    String toInfoStr = (String) toInfo;
                    String toClass = toInfoStr.split("-")[0];
                    String toMethod = toInfoStr.split("-")[1];
                    String toArgs = toInfoStr.split("-")[2];

                    String cToC = sendClass + " -->  " + toClass + "\n";
                    if (!grammars.contains(cToC) && !sendMethod.equals("main")) {
                        grammars.add(cToC);
                    }
                    if (sendMethod.equals("main") && flag) {
                        flag = false;
                        grammars.add(0, "Activate " + toClass);
                        grammars.add(0, sendClass + " -> " + toClass + ": " + toMethod + "(" + toArgs + ")");
                        if (!grammars.contains(cToC)) {
                            grammars.add(0, cToC);
                        }
                        grammars.add("Deactivate " + toClass);
                    } else {

                        grammars.add(sendClass + " -> " + toClass + ": " + toMethod + "(" + toArgs + ")");
                        grammars.add("Activate " + toClass);
                        grammars.add(toClass + " -> " + sendClass);
                        grammars.add("Deactivate " + toClass);
                    }

                }
            }
        }

        for (String g: grammars) {
            grammar += g + "\n";
        }

        grammar += "@enduml";

        OutputStream png = null;
        try {
            png = new FileOutputStream(outputImage);
            SourceStringReader reader = new SourceStringReader(grammar);
            String desc = reader.generateImage(png);
        }
        catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }
        catch (IOException e) {
            System.out.println("IO Exception");
        }

    }

    private HashMap<String, ArrayList> getMethodInfo(BodyDeclaration member) {
        HashMap<String, ArrayList> methodInfo = new HashMap<String, ArrayList>();
        MethodDeclaration method = (MethodDeclaration) member;
        String methodName = method.getName();
        String methodClass = "";

        if (method.getParentNode() instanceof ClassOrInterfaceDeclaration) {
            methodClass = ((ClassOrInterfaceDeclaration) method.getParentNode()).getName().toString();
        }

        HashMap<String, String> objClass = new HashMap<String, String>();
        if (method.getBody() != null) {
            for (Statement stmt: method.getBody().getStmts()) {
                if (stmt instanceof ExpressionStmt) {
                    Expression expr = ((ExpressionStmt) stmt).getExpression();
                    if (expr instanceof VariableDeclarationExpr) {
                        if (((VariableDeclarationExpr) expr).getType() instanceof ReferenceType) {
                            if (((ReferenceType) ((VariableDeclarationExpr) expr).getType()).getType() instanceof ClassOrInterfaceType) {
                                String clsName = ((ReferenceType) ((VariableDeclarationExpr) expr).getType()).getType().toString();
                                String objName = ((VariableDeclarationExpr) expr).getVars().get(0).getId().toString();
                                objClass.put(objName, clsName);
                            }
                        }
                    } else if (expr instanceof MethodCallExpr) {
                        String scope;
                        try {
                            scope = ((MethodCallExpr) expr).getScope().toString();
                        } catch (NullPointerException e) {
                            scope = "";
                        }

                        String args = "";

                        if (objClass.containsKey(scope)) {
                            String cName = objClass.get(scope);
                            String mName = ((MethodCallExpr) expr).getName().toString();

                            for (Expression a: ((MethodCallExpr) expr).getArgs()) {

                                String val = a.toString();

                                if (args.length() > 0) {
                                    args += ", " + val;
                                } else {
                                    args += val;
                                }

                            }

                            if (methodInfo.containsKey(methodClass + "-" + methodName)) {
                                ArrayList curVal = methodInfo.get(methodClass + "-" + methodName);
                                curVal.add(cName + "-" + mName + "-" + args);
                                methodInfo.put(methodClass + "-" + methodName, curVal);
                            } else {
                                ArrayList curVal = new ArrayList();
                                curVal.add(cName + "-" + mName + "-" + args);
                                methodInfo.put(methodClass + "-" + methodName, curVal);
                            }

                        } else if (scope.length() == 0) {
                            String mName = ((MethodCallExpr) expr).getName().toString();
                            if (methodInfo.containsKey(methodClass + "-" + methodName)) {
                                ArrayList curVal = methodInfo.get(methodClass + "-" + methodName);
                                curVal.add(methodClass + "-" + mName + "-" + args);
                                methodInfo.put(methodClass + "-" + methodName, curVal);
                            } else {
                                ArrayList curVal = new ArrayList();
                                curVal.add(methodClass + "-" + mName + "-" + args);
                                methodInfo.put(methodClass + "-" + methodName, curVal);
                            }
                        }
                    }
                }


            }
        }


        return methodInfo;

    }

    private static ArrayList<String> getClasses(CompilationUnit cu)
    {
        ArrayList classList = new ArrayList();
        for (TypeDeclaration typeDec : cu.getTypes()) {
            if(typeDec instanceof ClassOrInterfaceDeclaration && !((ClassOrInterfaceDeclaration) typeDec).isInterface())
            {
                classList.add(typeDec.getName());
            }
        }
        return classList;
    }


    private static ArrayList<String> getJavaFiles(final File folder) {
        ArrayList fileList = new ArrayList();
        for (final File fileEntry : folder.listFiles()) {
            String filePath = fileEntry.getPath();
            if (filePath.toLowerCase().endsWith(".java")) {
                fileList.add(filePath);
            }
        }
        return fileList;
    }


}
