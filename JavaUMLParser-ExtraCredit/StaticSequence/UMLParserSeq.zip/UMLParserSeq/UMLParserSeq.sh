#!/bin/sh
java -jar UMLParserSeq.jar $1 $2