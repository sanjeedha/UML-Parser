#!/bin/sh
java -jar UMLParserBS.jar $1 $2