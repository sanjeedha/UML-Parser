#!/bin/sh
java -jar UMLParser.jar $1 $2